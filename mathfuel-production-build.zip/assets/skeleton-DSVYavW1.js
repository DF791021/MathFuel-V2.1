import{j as s,H as a}from"./index-B2qn9B4L.js";function o({className:e,...t}){return s.jsx("div",{"data-slot":"skeleton",className:a("bg-accent animate-pulse rounded-md",e),...t})}export{o as S};
